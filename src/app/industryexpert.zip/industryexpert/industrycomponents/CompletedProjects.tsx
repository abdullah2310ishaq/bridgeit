"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { CalendarDays, Award, CheckCircle, FileText } from "lucide-react"

interface CompletedProject {
  id: string
  title: string
  description: string
  studentName: string
  endDate: string
  status: string
}

interface CompletedProjectsProps {
  expertId: string
}

const CompletedProjects = ({ expertId }: CompletedProjectsProps) => {
  const router = useRouter()
  const [projects, setProjects] = useState<CompletedProject[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchCompletedProjects = async () => {
      const token = localStorage.getItem("jwtToken")
      if (!token) {
        router.push("/auth/login-user")
        return
      }

      try {
        // Fetch assigned projects
        const res = await fetch(
          `https://api-bridgeit-htb0fpcee0ajb7a2.westindia-01.azurewebsites.net/api/projects/get-assigned-expert-projects?expertId=${expertId}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          },
        )

        if (!res.ok) {
          throw new Error("Failed to fetch projects")
        }

        const data = await res.json()

        // Filter only completed projects
        const completedProjects = data.filter((project: CompletedProject) => project.status === "Completed")

        setProjects(completedProjects)
      } catch (err) {
        console.error("Error fetching completed projects:", err)
        setError("Failed to load completed projects")
      } finally {
        setLoading(false)
      }
    }

    if (expertId) {
      fetchCompletedProjects()
    }
  }, [expertId, router])

  const handleViewProject = (projectId: string) => {
    router.push(`/industryexpert/projects/milestone/${projectId}`)
  }

  const handleViewReceipt = (projectId: string) => {
    router.push(`/industryexpert/payment-receipt/${projectId}`)
  }

  if (loading) {
    return (
      <div className="bg-gray-800 p-6 rounded-lg">
        <div className="flex justify-center">
          <div className="w-8 h-8 border-4 border-t-green-500 border-gray-600 rounded-full animate-spin"></div>
        </div>
        <p className="text-center text-gray-400 mt-4">Loading completed projects...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="bg-gray-800 p-6 rounded-lg">
        <p className="text-red-400">{error}</p>
      </div>
    )
  }

  if (projects.length === 0) {
    return (
      <div className="bg-gray-800 p-6 rounded-lg text-center">
        <CheckCircle className="w-12 h-12 text-gray-600 mx-auto mb-4" />
        <h3 className="text-xl font-semibold text-gray-300 mb-2">No Completed Projects</h3>
        <p className="text-gray-400">
          Projects will appear here once they are marked as completed and payment has been processed.
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-green-400 flex items-center">
        <CheckCircle className="w-6 h-6 mr-2" />
        Completed Projects
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <div
            key={project.id}
            className="bg-gradient-to-br from-green-900 to-gray-800 rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
          >
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-green-400">{project.title}</h3>
                <span className="bg-green-700 text-green-100 text-xs px-2 py-1 rounded-full">Completed</span>
              </div>

              <p className="text-gray-300 mb-4 line-clamp-2">{project.description}</p>

              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm">
                  <Award className="w-4 h-4 text-green-400 mr-2" />
                  <span className="text-gray-300">Student: {project.studentName}</span>
                </div>
                <div className="flex items-center text-sm">
                  <CalendarDays className="w-4 h-4 text-green-400 mr-2" />
                  <span className="text-gray-300">Completed: {new Date(project.endDate).toLocaleDateString()}</span>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  onClick={() => handleViewProject(project.id)}
                  className="py-2 px-3 bg-gray-700 hover:bg-gray-600 text-white rounded text-sm transition flex-1 flex items-center justify-center"
                >
                  <CheckCircle className="w-4 h-4 mr-1" />
                  View Details
                </button>
                <button
                  onClick={() => handleViewReceipt(project.id)}
                  className="py-2 px-3 bg-green-600 hover:bg-green-500 text-white rounded text-sm transition flex-1 flex items-center justify-center"
                >
                  <FileText className="w-4 h-4 mr-1" />
                  View Receipt
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 text-center">
        <Link
          href="/industryexpert/payment-history"
          className="text-green-400 hover:text-green-300 hover:underline inline-flex items-center"
        >
          <FileText className="w-4 h-4 mr-1" />
          View All Payment History
        </Link>
      </div>
    </div>
  )
}

export default CompletedProjects
