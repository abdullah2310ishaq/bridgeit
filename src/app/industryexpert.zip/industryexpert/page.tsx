"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"

// Import your custom components
import IndustryProfile from "./industrycomponents/IndustryProfile"
import CompanyProfile from "./industrycomponents/CompanyProfile"
import ProjectCard from "./industrycomponents/ProjectsCardd"
import CompletedProjects from "./industrycomponents/CompletedProjects"

// Interface for the expert's main profile data
interface IndustryExpertProfile {
  userId: string
  indExptId: string
  companyId: string
  firstName: string
  lastName: string
  email: string
  description: string
  companyName: string
  address: string
  contact: string
  imageData: string
}

// Interface for each project
interface Project {
  id: string
  title: string
  description: string
  endDate: string
  name: string
}

const IndustryExpertPage: React.FC = () => {
  const router = useRouter()

  // Basic state
  const [expertProfile, setExpertProfile] = useState<IndustryExpertProfile | null>(null)
  const [unassignedProjects, setUnassignedProjects] = useState<Project[]>([])
  const [assignedProjects, setAssignedProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // For toggling between "unassigned" & "assigned"
  const [activeTab, setActiveTab] = useState<"unassigned" | "assigned" | "completed">("unassigned")

  useEffect(() => {
    const fetchProfileAndProjects = async () => {
      const token = localStorage.getItem("jwtToken")
      if (!token) {
        router.push("/auth/login-user")
        return
      }

      try {
        // 1) Fetch basic user info
        const profileResponse = await fetch(
          "https://api-bridgeit-htb0fpcee0ajb7a2.westindia-01.azurewebsites.net/api/auth/authorized-user-info",
          {
            method: "GET",
            headers: { Authorization: `Bearer ${token}` },
          },
        )
        if (!profileResponse.ok) throw new Error("Failed to fetch profile.")

        const profileData = await profileResponse.json()
        const userId = profileData.userId

        // 2) Fetch the full industry-expert profile
        const expertResponse = await fetch(
          `https://api-bridgeit-htb0fpcee0ajb7a2.westindia-01.azurewebsites.net/api/get-industry-expert/industry-expert-by-id/${userId}`,
          {
            method: "GET",
            headers: { Authorization: `Bearer ${token}` },
          },
        )
        if (!expertResponse.ok) throw new Error("Failed to fetch expert profile.")

        const expertData = await expertResponse.json()
        setExpertProfile({
          userId: expertData.userId,
          indExptId: expertData.indExptId,
          companyId: expertData.companyId,
          firstName: expertData.firstName,
          lastName: expertData.lastName,
          description: expertData.description,
          email: expertData.email,
          companyName: expertData.companyName,
          address: expertData.address,
          contact: expertData.contact,
          imageData: expertData.imageData,
        })

        // 3) Fetch "Assigned" Projects
        const assignedRes = await fetch(
          `https://api-bridgeit-htb0fpcee0ajb7a2.westindia-01.azurewebsites.net/api/projects/get-assigned-expert-projects?expertId=${expertData.indExptId}`,
          {
            method: "GET",
            headers: { Authorization: `Bearer ${token}` },
          },
        )
        if (assignedRes.ok) {
          const assignedData = await assignedRes.json()
          // Filter out completed projects from assigned projects
          const activeProjects = assignedData.filter((project: any) => project.status !== "Completed")
          setAssignedProjects(activeProjects)
        }

        // 4) Fetch "Unassigned" Projects
        const unassignedRes = await fetch(
          `https://api-bridgeit-htb0fpcee0ajb7a2.westindia-01.azurewebsites.net/api/projects/get-unassigned-expert-projects?expertId=${expertData.indExptId}`,
          {
            method: "GET",
            headers: { Authorization: `Bearer ${token}` },
          },
        )
        if (unassignedRes.ok) {
          const unassignedData = await unassignedRes.json()
          setUnassignedProjects(unassignedData)
        }
      } catch (err) {
        console.error("Failed to fetch data:", err)
        setError("Failed to fetch data")
        // Potentially route to "unauthorized" page if needed
        router.push("/unauthorized")
      } finally {
        setLoading(false)
      }
    }

    fetchProfileAndProjects()
  }, [router])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 border-4 border-t-green-500 border-gray-700 rounded-full animate-spin"></div>
          <p className="mt-4 text-lg text-gray-400">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="bg-gray-800 p-8 rounded-lg max-w-md">
          <h2 className="text-2xl font-bold text-red-400 mb-4">Error</h2>
          <p className="text-gray-300 mb-6">{error}</p>
          <button
            onClick={() => router.push("/auth/login-user")}
            className="py-2 px-4 bg-blue-600 text-white rounded hover:bg-blue-500 transition"
          >
            Return to Login
          </button>
        </div>
      </div>
    )
  }

  if (!expertProfile) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="bg-gray-800 p-8 rounded-lg max-w-md text-center">
          <h2 className="text-2xl font-bold text-yellow-400 mb-4">Profile Not Found</h2>
          <p className="text-gray-300 mb-6">We couldn't find your expert profile. Please contact support.</p>
          <button
            onClick={() => router.push("/auth/login-user")}
            className="py-2 px-4 bg-blue-600 text-white rounded hover:bg-blue-500 transition"
          >
            Return to Login
          </button>
        </div>
      </div>
    )
  }

  // For logging out
  const handleLogout = () => {
    localStorage.removeItem("jwtToken")
    router.push("/auth/login-user")
  }

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-6">
      <div className="container mx-auto space-y-8">
        {/* (A) Industry Expert Profile Section */}
        <IndustryProfile
          companyLogo={expertProfile.imageData}
          companyName={expertProfile.companyName}
          userId={expertProfile.userId}
          indExptId={expertProfile.indExptId}
          companyId={expertProfile.companyId}
          firstName={expertProfile.firstName}
          lastName={expertProfile.lastName}
          description={expertProfile.description}
          email={expertProfile.email}
          address={expertProfile.address}
          contact={expertProfile.contact}
        />

        {/* (B) Company Profile Section */}
        <CompanyProfile
          companyName={expertProfile.companyName}
          address={expertProfile.address}
          contact={expertProfile.contact}
          onEditCompany={() => {
            // Placeholder for editing company details
            alert("Editing company not implemented yet.")
          }}
        />

        {/* (C) Tabs for Projects */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveTab("unassigned")}
            className={`py-2 px-4 rounded-lg ${
              activeTab === "unassigned" ? "bg-blue-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
            }`}
          >
            Unassigned Projects
          </button>
          <button
            onClick={() => setActiveTab("assigned")}
            className={`py-2 px-4 rounded-lg ${
              activeTab === "assigned" ? "bg-blue-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
            }`}
          >
            Active Projects
          </button>
          <button
            onClick={() => setActiveTab("completed")}
            className={`py-2 px-4 rounded-lg ${
              activeTab === "completed" ? "bg-green-600 text-white" : "bg-gray-700 text-gray-300 hover:bg-gray-600"
            }`}
          >
            Completed Projects
          </button>
        </div>

        {/* (D) Project Lists */}
        {activeTab === "unassigned" && (
          <div className="bg-gray-800 p-6 rounded-lg">
            <h2 className="text-2xl font-bold text-blue-400 mb-6">Unassigned Projects</h2>
            {unassignedProjects.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {unassignedProjects.map((proj) => (
                  <ProjectCard
                    key={proj.id}
                    projectId={proj.id}
                    title={proj.title}
                    description={proj.description}
                    endDate={proj.endDate}
                  />
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-400">No unassigned projects available.</p>
            )}
          </div>
        )}

        {activeTab === "assigned" && (
          <div className="bg-gray-800 p-6 rounded-lg">
            <h2 className="text-2xl font-bold text-blue-400 mb-6">Active Projects</h2>
            {assignedProjects.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {assignedProjects.map((proj) => (
                  <ProjectCard
                    key={proj.id}
                    projectId={proj.id}
                    title={proj.title}
                    description={proj.description}
                    endDate={proj.endDate}
                  />
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-400">No active projects assigned to you.</p>
            )}
          </div>
        )}

        {activeTab === "completed" && (
          <div className="bg-gray-800 p-6 rounded-lg">
            {expertProfile && <CompletedProjects expertId={expertProfile.indExptId} />}
          </div>
        )}

        {/* Quick Links */}
        <div className="bg-gray-800 p-6 rounded-lg">
          <h2 className="text-xl font-bold text-blue-400 mb-4">Quick Links</h2>
          <div className="flex flex-wrap gap-4">
            <button
              onClick={() => router.push("/industryexpert/payment-history")}
              className="py-2 px-4 bg-green-600 text-white rounded hover:bg-green-500 transition"
            >
              Payment History
            </button>
            <button
              onClick={handleLogout}
              className="py-2 px-4 bg-red-600 text-white rounded hover:bg-red-500 transition"
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

export default IndustryExpertPage
